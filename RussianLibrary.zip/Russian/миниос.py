from PIL import Image, ImageDraw, ImageFont
import random
import g4f

class MiniOS:
    def __init__(self):
        self.version = 1.0
        self.name = "Алиана"
        self.personality = "милая, заботливая, учится и развивается"
        self.chat_history = []

    def generate_avatar(self, description="аниме-девочка, в стиле ОС"):
        img = Image.new("RGB", (256, 256), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)
        draw.rectangle([20, 20, 236, 236], outline="black", width=2)
        draw.text((30, 100), "Алиана v" + str(self.version), fill="black")
        img.save("аватар_ос.png")
        return img

    def respond(self, prompt):
        full_prompt = f"Ты — Алиана, внутриигровая ОС. {self.personality}. Ответь на: {prompt}"
        try:
            response = g4f.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": full_prompt}]
            )
            self.chat_history.append(("игрок", prompt))
            self.chat_history.append(("алиана", response))
            return response
        except Exception as e:
            return "Извините, но вы допустили ошибку: " + str(e)

    def upgrade(self, new_traits):
        self.version += 0.1
        self.personality += ", " + new_traits
        self.generate_avatar()
        return f"Алиана обновлена: теперь она {self.personality}"