from russian import Russian, Gpt, oc, os

Russian.language("True")

Gpt.helper(
    oc.help,
    os.random.text.help,
    oc.input(">>>")
)